
const listeningExercises = [
  {
  id: 'L2',
  audio: 'audio/airport_announcement.mp3',
  question: 'What is the final destination of the flight?',
  choices: ['Tokyo', 'Paris', 'London'],
  answer: 2
},
{
  id: 'L3',
  audio: 'audio/voicemail_reminder.mp3',
  question: 'What is the purpose of the call?',
  choices: ['To cancel an appointment', 'To confirm a meeting', 'To request information'],
  answer: 1
},
{
  id: 'L4',
  audio: 'audio/weather_forecast.mp3',
  question: 'What will the temperature be this afternoon?',
  choices: ['12 degrees', '18 degrees', '24 degrees'],
  answer: 2
},
{
  id: 'L3',
  audio: 'audio/coffee_order.mp3',
  question: 'What does the customer order?',
  choices: ['A latte', 'A cappuccino', 'An iced tea'],
  answer: 0
},
{
  id: 'L4',
  audio: 'audio/train_delay.mp3',
  question: 'How long is the delay?',
  choices: ['5 minutes', '10 minutes', '20 minutes'],
  answer: 2
},
{
  id: 'L5',
  audio: 'audio/doctor_reminder.mp3',
  question: 'When is the appointment?',
  choices: ['Monday at 9 AM', 'Tuesday at 3 PM', 'Friday at 11 AM'],
  answer: 1
},
{
  id: 'L6',
  audio: 'audio/weather_forecast.mp3',
  question: 'What will the weather be like in the morning?',
  choices: ['Rainy', 'Sunny', 'Foggy'],
  answer: 0
},
{
  id: 'L13',
  audio: 'audio/university_orientation.mp3',
  question: 'Who is the event mainly for?',
  choices: ['New students', 'Parents', 'International alumni'],
  answer: 0
},
  ];

let currentL = 0;
function renderListening(i=0){
  const ex = listeningExercises[i];
  if(!ex){ document.getElementById('audioArea').innerHTML = '<div class="small">No listening exercises found. Add them in listening.js</div>'; return; }
  document.getElementById('audioArea').innerHTML = `<audio id="player" controls src="${ex.audio}"></audio>`;
  document.getElementById('listQuestion').textContent = ex.question;
  const ch = document.getElementById('listChoices'); ch.innerHTML = '';
  ex.choices.forEach((c,idx)=>{
    const b = document.createElement('button'); b.className='btn'; b.style.display='block'; b.style.margin='8px 0';
    b.textContent = c; b.onclick = ()=> {
      const correct = idx === ex.answer;
      if(correct){ addPoints(12); awardBadge('Listening Ace'); recordAttempt(true); alert('Correct! +12 pts'); }
      else { addPoints(2); recordAttempt(false); alert('Not quite — try next. +2 pts'); }
      if(i+1 < listeningExercises.length) renderListening(i+1);
      else alert('End of listening set');
    };
    ch.appendChild(b);
  });
}

renderListening(currentL);
